{
  "model": "openrouter/auto"
  // Other params
}