# This is conceptual, as actual token counting depends on the LLM API.

class LLMInteractionMonitor:
    def __init__(self):
        self.total_input_tokens = 0
        self.total_output_tokens = 0

    def record_interaction(self, prompt: str, response: str):
        """
        Record a single LLM interaction.

        Note:
            In a real-world scenario, use the LLM provider's
            token usage metadata or a tokenizer library
            (e.g., tiktoken) instead of word counts.
        """
        # Placeholder token counting logic
        input_tokens = len(prompt.split())
        output_tokens = len(response.split())

        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens

        print(
            f"Recorded interaction: "
            f"Input tokens={input_tokens}, "
            f"Output tokens={output_tokens}"
        )

    def get_total_tokens(self):
        """
        Return the cumulative input and output token counts.
        """
        return self.total_input_tokens, self.total_output_tokens


# --- Example Usage ---
monitor = LLMInteractionMonitor()

monitor.record_interaction(
    "What is the capital of France?",
    "The capital of France is Paris.",
)

monitor.record_interaction(
    "Tell me a joke.",
    "Why don't scientists trust atoms? Because they make up everything!",
)

input_tokens, output_tokens = monitor.get_total_tokens()

print(
    f"Total input tokens: {input_tokens}, "
    f"Total output tokens: {output_tokens}"
)