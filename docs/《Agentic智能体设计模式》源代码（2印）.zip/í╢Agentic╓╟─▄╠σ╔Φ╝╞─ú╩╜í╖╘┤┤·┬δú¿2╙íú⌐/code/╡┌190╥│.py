# Synchronous Request Example "id": "task-001", "sessionId": "session-001", "message":{"role": "user", "parts":[{"type": "text", "text": "What is the exchange rate from USD to EUR?" } ] }, "acceptedOutputModes":["text/plain"], "historyLength": 5 } }
{
  "jsonrpc": "2.0",
  "id": "1",
  "method": "sendTask",
  "params": {
    "id": "task-001",
    "sessionId": "session-001",
    "message": {
      "role": "user",
      "parts": [
        {
          "type": "text",
          "text": "What is the exchange rate from USD to EUR?"
        }
      ]
    },
    "acceptedOutputModes": ["text/plain"],
    "historyLength": 5
  }
}