import asyncio
from typing import Dict, Optional

from dotenv import load_dotenv
from langchain.agents import AgentExecutor, create_react_agent
from langchain.memory import ConversationBufferMemory
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.tools import Tool
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field

# --- 0. Configuration and Setup ---
load_dotenv()

llm = ChatOpenAI(
    temperature=0.5,
    model="gpt-4o-mini",
)


# --- 1. Task Management System ---
class Task(BaseModel):
    """Represents a single task in the system."""

    id: str
    description: str
    priority: Optional[str] = None  # P0, P1, P2
    assigned_to: Optional[str] = None  # Name of the worker


class SuperSimpleTaskManager:
    """An efficient and robust in-memory task manager."""

    def __init__(self):
        self.tasks: Dict[str, Task] = {}
        self.next_task_id = 1

    def create_task(self, description: str) -> Task:
        """Creates and stores a new task."""
        task_id = f"TASK-{self.next_task_id:03d}"
        new_task = Task(
            id=task_id,
            description=description,
        )

        self.tasks[task_id] = new_task
        self.next_task_id += 1

        print(f"DEBUG: Task created - {task_id}: {description}")
        return new_task

    def update_task(self, task_id: str, **kwargs) -> Optional[Task]:
        """Safely updates a task using Pydantic's model_copy."""
        task = self.tasks.get(task_id)

        if task:
            update_data = {
                key: value
                for key, value in kwargs.items()
                if value is not None
            }

            updated_task = task.model_copy(update=update_data)
            self.tasks[task_id] = updated_task

            print(f"DEBUG: Task {task_id} updated with {update_data}")
            return updated_task

        print(f"DEBUG: Task {task_id} not found for update.")
        return None

    def list_all_tasks(self) -> str:
        """Lists all tasks currently in the system."""
        if not self.tasks:
            return "No tasks in the system."

        task_strings = []

        for task in self.tasks.values():
            task_strings.append(
                f"ID: {task.id}, "
                f"Desc: '{task.description}', "
                f"Priority: {task.priority or 'N/A'}, "
                f"Assigned To: {task.assigned_to or 'N/A'}"
            )

        return "Current Tasks:\n" + "\n".join(task_strings)


task_manager = SuperSimpleTaskManager()


# --- 2. Tools for the Project Manager Agent ---
class CreateTaskArgs(BaseModel):
    description: str = Field(
        description="A detailed description of the task."
    )


class PriorityArgs(BaseModel):
    task_id: str = Field(
        description="The ID of the task to update, e.g., 'TASK-001'."
    )
    priority: str = Field(
        description="The priority to set. Must be one of: 'P0', 'P1', 'P2'."
    )


class AssignWorkerArgs(BaseModel):
    task_id: str = Field(
        description="The ID of the task to update, e.g., 'TASK-001'."
    )
    worker_name: str = Field(
        description="The name of the worker to assign the task to."
    )


def create_new_task_tool(description: str) -> str:
    """Creates a new project task with the given description."""
    task = task_manager.create_task(description)
    return f"Created task {task.id}: '{task.description}'."


def assign_priority_to_task_tool(task_id: str, priority: str) -> str:
    """Assigns a priority (P0, P1, P2) to a given task ID."""
    if priority not in ["P0", "P1", "P2"]:
        return "Invalid priority. Must be P0, P1, or P2."

    task = task_manager.update_task(
        task_id,
        priority=priority,
    )

    return (
        f"Assigned priority {priority} to task {task.id}."
        if task
        else f"Task {task_id} not found."
    )


def assign_task_to_worker_tool(task_id: str, worker_name: str) -> str:
    """Assigns a task to a specific worker."""
    task = task_manager.update_task(
        task_id,
        assigned_to=worker_name,
    )

    return (
        f"Assigned task {task.id} to {worker_name}."
        if task
        else f"Task {task_id} not found."
    )


pm_tools = [
    Tool(
        name="create_new_task",
        func=create_new_task_tool,
        description="Use this first to create a new task and get its ID.",
        args_schema=CreateTaskArgs,
    ),
    Tool(
        name="assign_priority_to_task",
        func=assign_priority_to_task_tool,
        description=(
            "Use this to assign a priority to a task after it has been created."
        ),
        args_schema=PriorityArgs,
    ),
    Tool(
        name="assign_task_to_worker",
        func=assign_task_to_worker_tool,
        description=(
            "Use this to assign a task to a specific worker after it has been created."
        ),
        args_schema=AssignWorkerArgs,
    ),
    Tool(
        name="list_all_tasks",
        func=task_manager.list_all_tasks,
        description="Use this to list all current tasks and their status.",
    ),
]


# --- 3. Project Manager Agent Definition ---
pm_prompt_template = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """
You are a focused Project Manager LLM agent.

Your goal is to manage project tasks efficiently.

When you receive a new task request, follow these steps:

1. First, create the task with the given description using the `create_new_task` tool.
   You must do this first to get a `task_id`.

2. Next, analyze the user's request to see if a priority or an assignee is mentioned.
   - If a priority is mentioned, such as "urgent", "ASAP", or "critical", map it to P0.
   - Use `assign_priority_to_task` for priority assignment.
   - If a worker is mentioned, use `assign_task_to_worker`.

3. If any information, such as priority or assignee, is missing, make a reasonable default assignment.
   For example, assign P1 priority and assign to "Worker A".

4. Once the task is fully processed, use `list_all_tasks` to show the final state.

Available workers:
- Worker A
- Worker B
- Review Team

Priority levels:
- P0: highest
- P1: medium
- P2: lowest
""",
        ),
        ("placeholder", "{chat_history}"),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ]
)

pm_agent = create_react_agent(
    llm,
    pm_tools,
    pm_prompt_template,
)

pm_agent_executor = AgentExecutor(
    agent=pm_agent,
    tools=pm_tools,
    verbose=True,
    handle_parsing_errors=True,
    memory=ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True,
    ),
)


# --- 4. Simple Interaction Flow ---
async def run_simulation():
    print("--- Project Manager Simulation ---")

    print(
        "\n[User Request] I need a new login system implemented ASAP. "
        "It should be assigned to Worker B."
    )

    await pm_agent_executor.ainvoke(
        {
            "input": (
                "Create a task to implement a new login system. "
                "It's urgent and should be assigned to Worker B."
            )
        }
    )

    print("\n" + "-" * 60 + "\n")

    print("[User Request] We need to review the marketing website content.")

    await pm_agent_executor.ainvoke(
        {
            "input": (
                "Manage a new task: Review marketing website content."
            )
        }
    )

    print("\n--- Simulation Complete ---")


if __name__ == "__main__":
    asyncio.run(run_simulation())