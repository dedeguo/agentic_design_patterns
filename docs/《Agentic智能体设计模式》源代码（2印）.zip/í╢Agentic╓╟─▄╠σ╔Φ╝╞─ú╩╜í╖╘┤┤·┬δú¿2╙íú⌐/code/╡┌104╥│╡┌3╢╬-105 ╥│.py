# Example: Using VertexAiSessionService
# This is suitable for scalable production on Google Cloud Platform,
# leveraging Vertex AI infrastructure for session management.
#
# Requires:
#   pip install google-adk[vertexai]
# and GCP setup/authentication.

from google.adk.sessions import VertexAiSessionService

PROJECT_ID = "your-gcp-project-id"  # Replace with your GCP project ID
LOCATION = "us-central1"  # Replace with your desired GCP location

# The app_name used with this service should correspond to the
# Reasoning Engine ID or name.
REASONING_ENGINE_APP_NAME = (
    "projects/your-gcp-project-id/"
    "locations/us-central1/"
    "reasoningEngines/your-engine-id"
)  # Replace with your Reasoning Engine resource name

session_service = VertexAiSessionService(
    project=PROJECT_ID,
    location=LOCATION,
)

# When using this service, pass REASONING_ENGINE_APP_NAME to service methods:
# session_service.create_session(app_name=REASONING_ENGINE_APP_NAME, ...)
# session_service.get_session(app_name=REASONING_ENGINE_APP_NAME, ...)
# session_service.append_event(session, event, app_name=REASONING_ENGINE_APP_NAME)
# session_service.delete_session(app_name=REASONING_ENGINE_APP_NAME, ...)