# Navigate to the project root directory
cd ./adk_agent_samples

# Start the ADK Web UI
adk web