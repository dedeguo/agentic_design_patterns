from langchain.chains import LLMChain
from langchain.memory import ConversationBufferMemory
from langchain_core.prompts import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    MessagesPlaceholder,
    SystemMessagePromptTemplate,
)
from langchain_openai import ChatOpenAI

# 1. Define Chat Model and Prompt
llm = ChatOpenAI()

prompt = ChatPromptTemplate(
    messages=[
        SystemMessagePromptTemplate.from_template(
            "You are a friendly assistant."
        ),
        MessagesPlaceholder(variable_name="chat_history"),
        HumanMessagePromptTemplate.from_template("{question}"),
    ]
)

# 2. Configure Memory
# return_messages=True is essential for chat models.
memory = ConversationBufferMemory(
    memory_key="chat_history",
    return_messages=True,
)

# 3. Build the Chain
conversation = LLMChain(
    llm=llm,
    prompt=prompt,
    memory=memory,
)

# 4. Run the Conversation
response = conversation.predict(
    question="Hi, I'm Jane."
)
print(response)

response = conversation.predict(
    question="Do you remember my name?"
)
print(response)