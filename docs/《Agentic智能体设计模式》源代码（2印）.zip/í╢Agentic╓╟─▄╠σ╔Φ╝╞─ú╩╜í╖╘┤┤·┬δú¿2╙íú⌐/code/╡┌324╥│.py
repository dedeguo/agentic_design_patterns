# A simple LCEL chain conceptually
# This is not runnable code; it only illustrates the flow.

chain = prompt | model | output_parser