# 1. Install required packages
pip install langchain_openai openai python-dotenv
然后在你的项目根目录下创建一个 .env 文件，内容如下：
OPENAI_API_KEY=your_openai_api_key_here