def evaluate_response_accuracy(agent_output: str, expected_output: str) -> float:
    """
    Calculates a simple accuracy score for agent responses.

    Note:
        This is a very basic exact-match metric.
        Real-world evaluation would use more sophisticated metrics,
        e.g., BLEU, ROUGE, or semantic similarity.
    """
    return 1.0 if agent_output.strip().lower() == expected_output.strip().lower() else 0.0


# --- Example Usage ---
agent_response = "The capital of France is Paris."
ground_truth = "Paris is the capital of France."

score = evaluate_response_accuracy(agent_response, ground_truth)

print(f"Response accuracy: {score}")