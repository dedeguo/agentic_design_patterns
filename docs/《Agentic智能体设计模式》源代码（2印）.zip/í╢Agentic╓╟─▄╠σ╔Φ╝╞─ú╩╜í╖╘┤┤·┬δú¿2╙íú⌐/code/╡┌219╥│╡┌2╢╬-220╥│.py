from google.adk.agents import Agent
from google.adk.tools import agent_tool, google_search
from google.adk.code_executors import BuiltInCodeExecutor

# Search Agent
search_agent = Agent(
    model="gemini-2.0-flash",
    name="SearchAgent",
    instruction="""
You're a specialist in Google Search.
""",
    tools=[google_search],
)

# Coding Agent
coding_agent = Agent(
    model="gemini-2.0-flash",
    name="CodeAgent",
    instruction="""
You're a specialist in Code Execution.
""",
    code_executor=[BuiltInCodeExecutor],
)

# Root Agent orchestrating Search and Coding Agents
root_agent = Agent(
    name="RootAgent",
    model="gemini-2.0-flash",
    description="Root Agent",
    tools=[
        agent_tool.AgentTool(agent=search_agent),
        agent_tool.AgentTool(agent=coding_agent),
    ],
)