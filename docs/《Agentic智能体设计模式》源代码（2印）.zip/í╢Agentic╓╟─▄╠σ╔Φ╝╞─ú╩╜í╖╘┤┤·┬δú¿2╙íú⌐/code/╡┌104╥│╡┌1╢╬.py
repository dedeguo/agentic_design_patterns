# Example: Using InMemorySessionService
# This is suitable for local development and testing where data
# persistence across application restarts is not required.

from google.adk.sessions import InMemorySessionService

session_service = InMemorySessionService()