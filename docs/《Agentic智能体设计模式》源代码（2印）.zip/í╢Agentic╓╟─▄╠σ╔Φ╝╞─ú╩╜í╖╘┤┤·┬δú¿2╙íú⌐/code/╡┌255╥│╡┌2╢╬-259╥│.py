import json
import logging
import os
from typing import Optional

import google.generativeai as genai

# --- Configuration ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

# Set your API key as an environment variable to run this script.
# Example:
#   export GOOGLE_API_KEY="your_key_here"
try:
    genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
except KeyError:
    logging.error("Error: GOOGLE_API_KEY environment variable not set.")
    exit(1)


# --- LLM-as-a-Judge Rubric for Legal Survey Quality ---
LEGAL_SURVEY_RUBRIC = """
You are an expert legal survey methodologist and a critical legal reviewer.

Your task is to evaluate the quality of a given legal survey question.

Provide a score from 1 to 5 for overall quality, along with a detailed rationale
and specific feedback.

Focus on the following criteria:

1. Clarity & Precision (Score 1-5)
2. Neutrality & Bias (Score 1-5)
3. Relevance & Focus (Score 1-5)
4. Completeness (Score 1-5)
5. Appropriateness for Audience (Score 1-5)

Output Format:

Your response MUST be a JSON object with the following keys:

{
  "overall_score": 1,
  "rationale": "Concise summary of the score.",
  "detailed_feedback": [
    "Feedback for clarity.",
    "Feedback for neutrality.",
    "Feedback for relevance.",
    "Feedback for completeness.",
    "Feedback for audience appropriateness."
  ],
  "concerns": [],
  "recommended_action": "Revise for neutrality"
}
"""


class LLMJudgeForLegalSurvey:
    """Evaluates legal survey questions using a generative AI model."""

    def __init__(
        self,
        model_name: str = "gemini-1.5-flash-latest",
        temperature: float = 0.2,
    ):
        """
        Initializes the LLM judge.

        Args:
            model_name: The Gemini model to use.
            temperature: Lower values are better for deterministic evaluation.
        """
        self.model = genai.GenerativeModel(model_name)
        self.temperature = temperature

    def _generate_prompt(self, survey_question: str) -> str:
        """Constructs the full prompt for the LLM judge."""
        return f"""
{LEGAL_SURVEY_RUBRIC}

---
LEGAL SURVEY QUESTION TO EVALUATE:
{survey_question}
---
"""

    def judge_survey_question(self, survey_question: str) -> Optional[dict]:
        """
        Judges the quality of a single legal survey question.

        Args:
            survey_question: The legal survey question to be evaluated.

        Returns:
            A dictionary containing the LLM's judgment, or None if an error occurs.
        """
        full_prompt = self._generate_prompt(survey_question)

        try:
            logging.info(
                "Sending request to '%s' for judgment...",
                self.model.model_name,
            )

            response = self.model.generate_content(
                full_prompt,
                generation_config=genai.types.GenerationConfig(
                    temperature=self.temperature,
                    response_mime_type="application/json",
                ),
            )

            if not response.parts:
                safety_ratings = response.prompt_feedback.safety_ratings
                logging.error(
                    "LLM response was empty or blocked. Safety ratings: %s",
                    safety_ratings,
                )
                return None

            return json.loads(response.text)

        except json.JSONDecodeError:
            logging.error(
                "Failed to decode LLM response as JSON. Raw response: %s",
                response.text,
            )
            return None

        except Exception as error:
            logging.error(
                "An unexpected error occurred during LLM judgment: %s",
                error,
            )
            return None


# --- Example Usage ---
if __name__ == "__main__":
    judge = LLMJudgeForLegalSurvey()

    good_legal_survey_question = """
To what extent do you agree or disagree that current intellectual property laws
in Switzerland adequately protect emerging AI-generated content, assuming the
content meets the originality criteria established by the Federal Supreme Court?

(Select one: Strongly Disagree, Disagree, Neutral, Agree, Strongly Agree)
"""

    print("\n--- Evaluating Good Legal Survey Question ---")
    judgment_good = judge.judge_survey_question(good_legal_survey_question)

    if judgment_good:
        print(json.dumps(judgment_good, indent=2))

    biased_legal_survey_question = """
Don't you agree that overly restrictive data privacy laws like the FADP are
hindering essential technological innovation and economic growth in Switzerland?

(Select one: Yes, No)
"""

    print("\n--- Evaluating Biased Legal Survey Question ---")
    judgment_biased = judge.judge_survey_question(biased_legal_survey_question)

    if judgment_biased:
        print(json.dumps(judgment_biased, indent=2))

    vague_legal_survey_question = """
What are your thoughts on legal tech?
"""

    print("\n--- Evaluating Vague Legal Survey Question ---")
    judgment_vague = judge.judge_survey_question(vague_legal_survey_question)

    if judgment_vague:
        print(json.dumps(judgment_vague, indent=2))