{
  "models": [
    "anthropic/claude-3.5-sonnet",
    "gryphe/mythomax-l2-13b"
  ],

  // Other params
}