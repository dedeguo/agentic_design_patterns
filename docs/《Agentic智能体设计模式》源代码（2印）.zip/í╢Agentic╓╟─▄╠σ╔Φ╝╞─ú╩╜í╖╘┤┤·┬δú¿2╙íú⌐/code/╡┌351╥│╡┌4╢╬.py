PHASE 4 — RESPONSE GENERATION

Plan Response Structure

- Restate the question.
- Show the computed values.
- State the conclusion.

Surface Realization

"3⁴ is 81 and 4³ is 64, so 3⁴ is larger."