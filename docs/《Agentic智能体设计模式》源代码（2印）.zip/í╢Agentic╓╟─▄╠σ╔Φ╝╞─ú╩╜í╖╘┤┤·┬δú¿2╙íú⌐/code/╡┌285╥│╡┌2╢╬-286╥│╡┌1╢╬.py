class ProfessorAgent(BaseAgent):
    def __init__(
        self,
        model="gpt4omini",
        notes=None,
        max_steps=100,
        openai_api_key=None,
    ):
        super().__init__(
            model,
            notes,
            max_steps,
            openai_api_key,
        )

        self.phases = ["report writing"]

    def generate_readme(self):
        sys_prompt = f"""
You are {self.role_description()}

Here is the written paper:
{self.report}

Task instructions:
Your goal is to integrate all of the knowledge, code, reports,
and notes provided to you and generate a README.md for a
GitHub repository.
"""

        history_str = "\n".join([item[1] for item in self.history])

        prompt = (
            f"History: {history_str}\n"
            f"{'~' * 10}\n"
            "Please produce the README below in markdown:\n"
        )

        model_resp = query_model(
            model_str=self.model,
            system_prompt=sys_prompt,
            prompt=prompt,
            openai_api_key=self.openai_api_key,
        )

        return model_resp.replace("```markdown", "")