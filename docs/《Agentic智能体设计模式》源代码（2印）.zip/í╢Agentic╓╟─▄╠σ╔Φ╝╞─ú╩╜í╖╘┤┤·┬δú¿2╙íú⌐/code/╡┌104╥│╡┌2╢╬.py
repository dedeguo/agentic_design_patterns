# Example: Using DatabaseSessionService
# This is suitable for production or development requiring
# persistent storage.
#
# You need to configure a database URL
# (e.g., for SQLite, PostgreSQL, etc.).
#
# Requires:
#   pip install google-adk[sqlalchemy]
# and a database driver
# (e.g., psycopg2 for PostgreSQL)

from google.adk.sessions import DatabaseSessionService

# Example using a local SQLite file:
db_url = "sqlite:///./my_agent_data.db"

session_service = DatabaseSessionService(
    db_url=db_url
)