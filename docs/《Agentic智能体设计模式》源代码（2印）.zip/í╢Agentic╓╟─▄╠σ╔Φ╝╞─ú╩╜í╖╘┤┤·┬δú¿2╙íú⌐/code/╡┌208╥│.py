import json
import requests

response = requests.post(
    url="https://openrouter.ai/api/v1/chat/completions",
    headers={
        "Authorization": "Bearer <OPENROUTER_API_KEY>",
        # Optional: Site URL for rankings on openrouter.ai
        "HTTP-Referer": "<YOUR_SITE_URL>",
        # Optional: Site title for rankings on openrouter.ai
        "X-Title": "<YOUR_SITE_NAME>",
        "Content-Type": "application/json",
    },
    data=json.dumps(
        {
            "model": "openai/gpt-4o",  # Optional
            "messages": [
                {
                    "role": "user",
                    "content": "What is the meaning of life?",
                }
            ],
        }
    ),
)

print(response.json())