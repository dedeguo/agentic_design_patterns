@crew
def crew(self) -> Crew:
    """Creates the research crew."""
    return Crew(
        agents=self.agents,
        tasks=self.tasks,
        process=Process.sequential,
        verbose=True,
    )