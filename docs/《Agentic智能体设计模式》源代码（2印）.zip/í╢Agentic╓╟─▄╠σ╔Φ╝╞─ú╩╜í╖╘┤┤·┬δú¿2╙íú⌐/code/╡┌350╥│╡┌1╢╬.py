PHASE 0 — INPUT PRE-PROCESSING

Tokenization

I break the text into discrete symbols:

["Which", "is", "larger", ":", "3", "^", "4", "or", "4", "^", "3", "?"]

Syntactic Parsing

I recognize the structure:

- COMPARATIVE_QUERY
  - Superlative adjective: "larger"
  - Two NUMERICAL_EXPONENT_TERMS:
    - 3^4
    - 4^3

Semantic Mapping

I map "larger" to the numerical relation ">".